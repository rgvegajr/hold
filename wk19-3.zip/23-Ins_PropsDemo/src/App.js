import React from "react";
import Alert from "./components/Alert";

function App() {
  return <Alert type="danger">Invalid user id or password</Alert>;
}

export default App;
